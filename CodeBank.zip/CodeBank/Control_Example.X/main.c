#include <atmel_start.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
    
    
   /*led_setting is the current state of the LED. On = True, Off = False.*/
    bool led_setting = false;
	
	while (1) {
        
        /*waits 1 second before repeating the loop*/
        delay_ms(1000); 
        
        /*This changes the LED state to on/off and then sends that state to the GPIO Port*/
        led_setting =!led_setting;
        gpio_set_pin_level(LED, led_setting);
        
        
	}
}
