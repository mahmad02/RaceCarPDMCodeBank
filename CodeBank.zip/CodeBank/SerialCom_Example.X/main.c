#include <atmel_start.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
    USART_0_example(); //Shows that USART works, should display "System Ready!" to COM Port
    
    /* Variables used for LED States and Debounce*/
    bool led_setting = false;
    bool ready = true;
	
    while (1) {
        
        /*This if statement checks for the onboard button click*/
        if(!(SW0 & gpio_get_pin_level(SW0))){
            
            /* This if statement checks for the debounce variable. 
             Without it, the LED would turn on and off very quickly 
             due to processor cycling through the code quickly as the 
             button is depressed. This provides support to holding the button.*/
            if (ready) {
                led_setting =!led_setting;
                ready = false;

                if (!led_setting)
                    LED_on();
                else
                    LED_off();
            }
        }
        
        /*This clears the debounce variable. As soon as the button is released,
         it can be pressed again.*/
        if((SW0 & gpio_get_pin_level(SW0))){
                ready = true;
        }
        
        /*This sets the LED to its desired state.*/
        gpio_set_pin_level(LED, led_setting);
    }
	
}
