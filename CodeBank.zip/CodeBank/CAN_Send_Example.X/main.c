#include <atmel_start.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
    
    
	while (1) {
        /*Send a message with id 0x45A, DATA = 1,2,3,4*/
        CAN_1_send();
        delay_us(120);
        
        /*Disable the CANBUS*/
        can_async_disable(&CAN_1);
        
        /*Wait 4 seconds before resending*/
        delay_ms(4000);
	}
}
