#include <atmel_start.h>

char* measured[4];

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
    
    /*The variables declared decide what voltage we are looking for when using the ADC
     and also control the settings of the LEDs on the board*/
    uint8_t * num =0;
    int turnonVoltage = 2048;
	bool led_setting = false;
    bool led2_setting = false;
    bool ready = true;
    
	while (1) {
        
        /* If the ADC Measures a value that is less than the voltage we are looking for, 
         Then keep the LED off. Else, turn on the LED.*/
        if (num < turnonVoltage)
            led2_setting = false;
        else
            led2_setting = true;
        
        /*Button code from earlier examples.*/
        if(!(SW0 & gpio_get_pin_level(SW0))){
            if (ready) {
                led_setting =!led_setting;
                ready = false;
                
                if (!led_setting)
                    LED_on();
                else
                    LED_off();
                
            }
        }
        if((SW0 & gpio_get_pin_level(SW0))){
                ready = true;
                
        }
        
        /*This code sets the LED to its correct state.*/
        gpio_set_pin_level(LED, led_setting);
        gpio_set_pin_level(LED2, led2_setting);
        
        /*This portion runs the ADC and passes the result into a local variable.*/
        ADC_0_example();
        num = ADC0->RESULT.reg;
        
	}
}