#include <atmel_start.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
    
	/* Replace with your application code */
	while (1) {
        CAN_1_Receive();
        delay_us(120);
        can_async_disable(&CAN_1);
        delay_ms(4000);
	}
}
